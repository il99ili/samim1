# 📁 دليل المنصة الكامل
## هيكل الملفات

```
platform/
├── index.html      ← الصفحة الرئيسية (Landing Page)
├── client.html     ← لوحة تحكم العميل
├── admin.html      ← لوحة الإدارة والموظفين
├── css/
│   └── style.css   ← كل التنسيق والألوان
├── js/
│   └── main.js     ← كل الوظائف التفاعلية
└── README.md       ← هذا الملف
```

---

## 🎨 كيف تعدّل الألوان؟

افتح `css/style.css` وابحث عن `:root` في البداية:

```css
:root {
  --primary:       #00615B;   ← اللون الأساسي (الأخضر)
  --primary-light: #00877f;   ← نسخة أفتح منه
  --gray-light:    #E4E4E4;   ← الرمادي الفاتح
  --black:         #0a0a0a;   ← خلفية الصفحة
}
```

غيّر `#00615B` بأي كود لوني تبغاه — سيتغير في كل المنصة تلقائياً.

---

## ✏️ كيف تعدّل النصوص؟

| ما تبغى تعدّله | الملف | ابحث عن |
|---|---|---|
| اسم المؤسسة | `index.html` | `إبداع` |
| الشعار | `index.html` | `class="nav-logo"` |
| وصف الهيرو | `index.html` | `class="hero"` |
| الخدمات | `index.html` | `class="service-card"` |
| الإحصائيات | `index.html` | `class="stat-num"` |
| اسم العميل | `client.html` | `id="userName"` |
| اسم المدير | `admin.html` | `class="user-name"` |

---

## 🔗 خارطة الربط بالـ Backend

### الخطوة 1 — اختر تقنية الـ Backend
| خيار | مناسب لـ | الصعوبة |
|---|---|---|
| **Laravel (PHP)** | مشاريع كبيرة، مجتمع عربي واسع | متوسطة |
| **Node.js + Express** | سرعة التطوير | متوسطة |
| **Supabase** | بداية سريعة، بدون سيرفر | سهلة |
| **Firebase** | تطبيقات صغيرة ومتوسطة | سهلة |

### الخطوة 2 — قاعدة البيانات
```sql
-- الجداول الأساسية التي تحتاجها

CREATE TABLE users (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100),
  email       VARCHAR(100) UNIQUE,
  phone       VARCHAR(20),
  role        ENUM('admin','staff','client'),  -- الصلاحية
  password    VARCHAR(255),
  created_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE orders (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  client_id   INT REFERENCES users(id),
  designer_id INT REFERENCES users(id),       -- المصمم المعيّن
  service     VARCHAR(100),                   -- نوع الخدمة
  type        ENUM('real','mock'),             -- حقيقي أو وهمي
  status      ENUM('new','inprogress','waiting','done'),
  notes       TEXT,
  created_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE messages (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  order_id    INT REFERENCES orders(id),
  sender_id   INT REFERENCES users(id),
  body        TEXT,
  sent_at     TIMESTAMP DEFAULT NOW()
);

CREATE TABLE versions (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  order_id    INT REFERENCES orders(id),
  version_num VARCHAR(10),                    -- V1, V2, V3...
  file_url    VARCHAR(500),                   -- رابط الملف في S3
  notes       TEXT,
  created_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE approvals (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  order_id    INT REFERENCES orders(id),
  version_id  INT REFERENCES versions(id),
  type        ENUM('file','stage'),
  status      ENUM('pending','approved','rejected'),
  comment     TEXT,
  responded_at TIMESTAMP
);

CREATE TABLE appointments (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  client_id   INT REFERENCES users(id),
  date        DATE,
  time        TIME,
  type        ENUM('online','physical'),
  status      ENUM('available','booked','cancelled'),
  zoom_link   VARCHAR(500)                    -- لو كان أونلاين
);

CREATE TABLE contracts (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  client_id   INT REFERENCES users(id),
  order_id    INT REFERENCES orders(id),
  type        ENUM('nda','service','amendments'),
  file_url    VARCHAR(500),
  signed_at   TIMESTAMP,
  status      ENUM('pending','signed')
);

CREATE TABLE payments (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  order_id    INT REFERENCES orders(id),
  amount      DECIMAL(10,2),
  method      ENUM('apple_pay','card','mada','tamara','tabby'),
  status      ENUM('pending','completed','failed'),
  invoice_url VARCHAR(500),
  paid_at     TIMESTAMP
);
```

### الخطوة 3 — الـ API Endpoints
```
# الطلبات
GET    /api/orders              ← جدول الطلبات في الإدارة
POST   /api/orders              ← إنشاء طلب جديد
GET    /api/orders/:id          ← تفاصيل طلب
PATCH  /api/orders/:id          ← تعديل حالة أو تعيين مصمم

# الرسائل
GET    /api/orders/:id/messages ← رسائل الشات
POST   /api/messages            ← إرسال رسالة جديدة

# الإصدارات
GET    /api/orders/:id/versions ← سجل الإصدارات
POST   /api/versions            ← رفع إصدار جديد

# الاعتمادات
GET    /api/approvals?client_id=:id  ← الاعتمادات المعلقة
POST   /api/approvals/:id/approve   ← موافقة
POST   /api/approvals/:id/reject    ← رفض مع تعليق

# المواعيد
GET    /api/appointments?month=6    ← مواعيد الشهر
POST   /api/appointments            ← إضافة موعد
PATCH  /api/appointments/:id        ← تعديل موعد

# العقود
GET    /api/contracts               ← قائمة العقود
POST   /api/contracts/:id/send      ← إرسال للتوقيع
POST   /api/contracts/:id/remind    ← إرسال تذكير

# الدفع
POST   /api/payments/initiate       ← بدء عملية الدفع
POST   /api/payments/webhook        ← استقبال نتيجة الدفع من البوابة
```

### الخطوة 4 — كيف تربط الـ Frontend بالـ API
```javascript
// مثال: جلب الطلبات وعرضها في الجدول
async function loadOrders() {
  try {
    const response = await fetch('/api/orders', {
      headers: {
        'Authorization': 'Bearer ' + localStorage.getItem('token')
      }
    });
    const data = await response.json();
    
    // ارسم الصفوف في الجدول
    const tbody = document.querySelector('#ordersTable tbody');
    tbody.innerHTML = '';
    
    data.orders.forEach(order => {
      tbody.innerHTML += `
        <tr>
          <td>#${order.id}</td>
          <td>${order.client.name}</td>
          <td>${order.service}</td>
          <td>${order.status}</td>
          ...
        </tr>
      `;
    });
    
  } catch (error) {
    console.error('خطأ في جلب الطلبات:', error);
  }
}
```

---

## 📱 الإشعارات (SMS + Email)

### SMS — خيارات للسعودية
| الخدمة | الموقع | ملاحظة |
|---|---|---|
| **Taqnyat** | taqnyat.sa | الأرخص والأسرع في السعودية |
| **Unifonic** | unifonic.com | موثوق ومنتشر |
| **Twilio** | twilio.com | دولي، أغلى قليلاً |

```javascript
// مثال إرسال SMS عبر Taqnyat
async function sendSMS(phone, message) {
  await fetch('https://api.taqnyat.sa/v1/messages', {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer YOUR_API_KEY',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      recipients: [phone],
      body: message,
      sender: 'IBDA3'  // اسم المرسل (يحتاج موافقة)
    })
  });
}
```

### Email
| الخدمة | المجانية | الملاحظة |
|---|---|---|
| **SendGrid** | 100/يوم | الأشهر والأسهل |
| **Mailgun** | 5000/شهر | ممتاز للـ API |
| **Amazon SES** | أرخص سعراً | لكن أصعب إعداداً |

---

## 💳 بوابات الدفع

### HyperPay (الأنسب للسعودية)
```html
<!-- 1. أضف سكريبت HyperPay -->
<script src="https://eu-test.oppwa.com/v1/paymentWidgets.js?checkoutId=CHECKOUT_ID"></script>

<!-- 2. أضف نموذج الدفع -->
<form action="/api/payments/result" class="paymentWidgets" 
      data-brands="VISA MASTER MADA APPLEPAY">
</form>
```

### Tamara (التقسيط)
```javascript
// تهيئة Tamara
const tamara = new TamaraCheckout({
  publicKey: 'YOUR_PUBLIC_KEY',
  sandbox: true,  // false في الإنتاج
});
```

---

## 🔐 التوقيع الإلكتروني

### DocuSign (الأكثر انتشاراً)
```javascript
// إرسال عقد للتوقيع
async function sendForSignature(contractId, clientEmail) {
  await fetch('/api/contracts/' + contractId + '/send', {
    method: 'POST',
    body: JSON.stringify({ email: clientEmail })
    // الـ Backend يتكلم مع DocuSign API
  });
}
```

### البديل المجاني — PDF + رفع يدوي
لو ما أبغيت DocuSign (غالي)، يمكن:
1. الموظف يرفع PDF العقد
2. العميل يحمّله ويوقّع ويرفعه
3. أبسط وأرخص لكن أقل احترافية

---

## ☁️ التخزين السحابي للملفات

### Amazon S3 (الأشهر)
```javascript
// رفع ملف إصدار التصميم
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');

const s3 = new S3Client({ region: 'me-south-1' }); // السعودية

async function uploadVersion(file, orderId, versionNum) {
  const key = `orders/${orderId}/versions/${versionNum}/${file.name}`;
  
  await s3.send(new PutObjectCommand({
    Bucket: 'your-bucket-name',
    Key: key,
    Body: file.buffer,
    ContentType: file.mimetype,
  }));
  
  return `https://your-bucket.s3.amazonaws.com/${key}`;
}
```

### Supabase Storage (أسهل للمبتدئين)
```javascript
const { data } = await supabase.storage
  .from('designs')
  .upload(`orders/${orderId}/${fileName}`, file);
```

---

## 🚀 خطوات الإطلاق

```
1. اشترِ دومين (مثل: ibda3.sa)
2. اشترِ استضافة (VPS على DigitalOcean أو SaudiCloud)
3. ثبّت: Node.js أو PHP + MySQL + Nginx
4. ارفع الملفات
5. اربط الدومين بالاستضافة
6. فعّل SSL (شهادة HTTPS مجانية من Let's Encrypt)
7. اربط بوابة الدفع وخدمة SMS
8. اختبر كل شيء قبل الإطلاق
```

---

## 📞 ترتيب أولويات الربط

```
المرحلة 1 (الأساس):
✅ قاعدة البيانات + API
✅ تسجيل الدخول والصلاحيات
✅ إدارة الطلبات والشات

المرحلة 2 (المتقدمة):
✅ المواعيد
✅ الإشعارات (SMS + Email)
✅ رفع الملفات

المرحلة 3 (الاحترافية):
✅ بوابة الدفع
✅ التوقيع الإلكتروني
✅ الفوترة التلقائية
```
